function Sidebar(){
    return (<>
         <div ClassName="sidebar_container">  		  
		<div ClassName="sidebar">
          <div ClassName="sidebar_item">
            <h2>Latest Blog</h2>
			<h4>April 2012</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque cursus tempor enim.</p>
		      <a href="#">Read more</a>
           </div>
         </div>   		
	    <div ClassName="sidebar">
          <div ClassName="sidebar_item">
            <h2>Latest Blog</h2>
		  	<h4>April 2012</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque cursus tempor enim.</p>
		      <a href="#">Read more</a>
          </div>
        </div>
		<div ClassName="sidebar">
          <div ClassName="sidebar_item">
            <h2>Latest Blog</h2>
			<h4>April 2012</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque cursus tempor enim.</p>
		      <a href="#">Read more</a>
          </div>
        </div> 
      </div>
	  
    </>

    )
}
export default Sidebar;