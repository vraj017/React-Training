import Footer from './Footer';
import Header from './Header';
import Sidebar from './Sidebar';
function Testimonials(){
    return(<>
    <div id="main">	
	<div id="site_content">
   <Header/>
   <div id="content">
          <h2>Testimonials</h2>
		  <h3>Example 1</h3>
          <br/>
	      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec quis sapien vel orci posuere tristique quis vitae nisi. Sed porta venenatis auctor. Fusce iaculis ligula odio. Etiam malesuada dui sit amet eros pharetra interdum. Phasellus consectetur blandit nulla, quis laoreet tellus condimentum nec. Integer diam tellus, molestie id convallis in, pellentesque tempus arcu. In congue ornare laoreet. Ut vel dui tincidunt quam sollicitudin aliquet ut a nibh.</p>
	      <br />
            
	      <h3>Example 2</h3>
          <br/>
	      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec quis sapien vel orci posuere tristique quis vitae nisi. Sed porta venenatis auctor. Fusce iaculis ligula odio. Etiam malesuada dui sit amet eros pharetra interdum. Phasellus consectetur blandit nulla, quis laoreet tellus condimentum nec. Integer diam tellus, molestie id convallis in, pellentesque tempus arcu. In congue ornare laoreet. Ut vel dui tincidunt quam sollicitudin aliquet ut a nibh.</p>
	      <br />
		  
	      <h3>Example 3</h3>
          <br/>
	      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec quis sapien vel orci posuere tristique quis vitae nisi. Sed porta venenatis auctor. Fusce iaculis ligula odio. Etiam malesuada dui sit amet eros pharetra interdum. Phasellus consectetur blandit nulla, quis laoreet tellus condimentum nec. Integer diam tellus, molestie id convallis in, pellentesque tempus arcu. In congue ornare laoreet. Ut vel dui tincidunt quam sollicitudin aliquet ut a nibh.</p>
	      <br />	  
      </div>
      <Sidebar/>
	  
    </div>
    <Footer/>
  </div>
    </>

    )
}

export default Testimonials;