function Footer(){
    return (<>
    <div id="footer">
	<p>2024. My SAP sspl . All rights reserved. Design by SSPL-1384</p>
</div>
    </>
    );
}

export default Footer;